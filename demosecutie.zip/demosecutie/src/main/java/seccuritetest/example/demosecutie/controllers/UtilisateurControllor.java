package seccuritetest.example.demosecutie.controllers;
import java.util.*;
import java.util.stream.Collectors;

import javax.validation.Valid;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.security.crypto.password.PasswordEncoder;

import seccuritetest.example.demosecutie.model.ERole;
import seccuritetest.example.demosecutie.model.Role;
import seccuritetest.example.demosecutie.model.User;
import seccuritetest.example.demosecutie.payload.request.LoginRequest;
import seccuritetest.example.demosecutie.payload.request.SignUpRequest;
import seccuritetest.example.demosecutie.payload.request.UpdateUserRequest;
import seccuritetest.example.demosecutie.payload.response.JwtResponse;
import seccuritetest.example.demosecutie.payload.response.MessageResponse;
import seccuritetest.example.demosecutie.repository.RoleRepository;
import seccuritetest.example.demosecutie.repository.UserRepository;
import seccuritetest.example.demosecutie.security.jwt.JwtUtils;
import seccuritetest.example.demosecutie.services.UserDetailsImpl;


@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@Slf4j
@RequestMapping("/api/user")
public class UtilisateurControllor {
    @Autowired
    AuthenticationManager authenticationManager;

    @Autowired
    UserRepository userRepository;

    @Autowired
    RoleRepository roleRepository;

    @Autowired
    PasswordEncoder encoder;

    @Autowired
    JwtUtils jwtUtils;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired


    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/user")
    public List<User> getAllUtilisateur() {
        System.out.println("Get all Utilisateur...");

        List<User> Utilisateur = new ArrayList<>();
        userRepository.findAll().forEach(Utilisateur::add);

        return Utilisateur;
    }

    //Registre utlisateur
    @PostMapping("/signup")
    public ResponseEntity<?> registerUser(@Valid @RequestBody SignUpRequest signUpRequest) {
        if (userRepository.existsByUsername(signUpRequest.getUsername())) {
            return ResponseEntity
                    .badRequest()
                    .body(new MessageResponse("Error: Username is already taken!"));
        }


        if (userRepository.existsByEmail(signUpRequest.getEmail())) {
            return ResponseEntity
                    .badRequest()
                    .body(new MessageResponse("Error: Email is already in use!"));
        }

        // Create new user's account
        User user = new User(signUpRequest.getUsername(),
                signUpRequest.getEmail(),
                encoder.encode(signUpRequest.getPassword())
        );

        Set<String> strRoles = signUpRequest.getRole();
        System.out.println(signUpRequest.getRole());
        Set<Role> roles = new HashSet<>();


        if (strRoles == null) {
            Role userRole = roleRepository.findByName(ERole.ROLE_CLIENT)
                    .orElseThrow(() -> new RuntimeException("Error: Role is not found."));
            roles.add(userRole);
        } else {
            strRoles.forEach(role -> {
                switch (role) {
                    case "admin":
                        Role adminRole = roleRepository.findByName(ERole.ROLE_ADMIN)
                                .orElseThrow(() -> new RuntimeException("Error: Role is not found."));
                        roles.add(adminRole);

                        break;
                    case "int":
                        Role modRole = roleRepository.findByName(ERole.ROLE_INTERNAUTE)
                                .orElseThrow(() -> new RuntimeException("Error: Role is not found."));
                        roles.add(modRole);

                        break;
                    default:
                        Role userRole = roleRepository.findByName(ERole.ROLE_CLIENT)
                                .orElseThrow(() -> new RuntimeException("Error: Role is not found."));
                        roles.add(userRole);
                }
            });
        }

        user.setRoles(roles);
        userRepository.save(user);

        return ResponseEntity.ok(new MessageResponse("User registered successfully!"));
    }


    ////update user
    @PutMapping("/users/{id}")
    public ResponseEntity<?> updateUser(@PathVariable Long id, @Valid @RequestBody UpdateUserRequest UpdateUserRequest) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("User not found with id: " + id));

        // Update user's information
        user.setUsername(UpdateUserRequest.getUsername());
        user.setEmail(UpdateUserRequest.getEmail());
        // Check if the old password matches the current password
        if (!encoder.matches(UpdateUserRequest.getOldPassword(), user.getPassword())) {
            return ResponseEntity
                    .badRequest()
                    .body(new MessageResponse("Error: Old password is incorrect."));
        }
        // Update the user's password with the new one
        user.setPassword(encoder.encode(UpdateUserRequest.getNewPassword()));
        // user.setPassword(encoder.encode(UpdateUserRequest .getPassword())); // You can choose to update the password or not
        userRepository.save(user);
        return ResponseEntity.ok(new MessageResponse("User updated successfully!"));
    }
}


    //update password
 /*   @PutMapping("/changepassword/{id}")
    public ResponseEntity<?> changePassword(@PathVariable Long id,
                                            @Valid @RequestBody ChangePasswordRequest changePasswordRequest) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("User not found with id: " + id));


        // Check if the old password matches the current password
        if (!encoder.matches(changePasswordRequest.getOldPassword(), user.getPassword())) {
            return ResponseEntity
                    .badRequest()
                    .body(new MessageResponse("Error: Old password is incorrect."));
        }

        // Update the user's password with the new one
        user.setPassword(encoder.encode(changePasswordRequest.getNewPassword()));
        userRepository.save(user);

        return ResponseEntity.ok(new MessageResponse("Password changed successfully!"));
    }
    }
*/

/*
    private void validate(ChangePasswordRequest dto) {
        if (dto == null) {
            log.warn("Impossible de modifier le mot de passe avec un objet NULL");
            throw new RuntimeException("Aucune information n'a ete fourni pour pouvoir changer le mot de passe");
        }
        if (dto.getId() == null) {
            log.warn("Impossible de modifier le mot de passe avec un ID NULL");
            throw new RuntimeException("ID utilisateur null:: Impossible de modifier le mote de passe");
        }
        if (!StringUtils.hasLength(dto.getMotDePasse()) || !StringUtils.hasLength(dto.getConfirmMotDePasse())) {
            log.warn("Impossible de modifier le mot de passe avec un mot de passe NULL");
            throw new RuntimeException("Mot de passe utilisateur null:: Impossible de modifier le mote de passe");
        }
        if (!dto.getMotDePasse().equals(dto.getConfirmMotDePasse())) {
            log.warn("Impossible de modifier le mot de passe avec deux mots de passe different");
            throw new RuntimeException("Mots de passe utilisateur non conformes:: Impossible de modifier le mote de passe");
        }
    }*/



