package seccuritetest.example.demosecutie.security.jwt;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.util.StringUtils;
import org.springframework.web.filter.OncePerRequestFilter;

import seccuritetest.example.demosecutie.services.UserDetailsServiceImpl;
public class AuthTokenFilter extends OncePerRequestFilter {
    @SuppressWarnings("SpringJavaInjectionPointsAutowiringInspection")
    @Autowired
    private JwtUtils jwtUtils;

    @SuppressWarnings("SpringJavaInjectionPointsAutowiringInspection")
    @Autowired
    private UserDetailsServiceImpl userDetailsService;

    private static final Logger logger = LoggerFactory.getLogger(AuthTokenFilter.class);



    //Filtrer les demandes
    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
            throws ServletException, IOException { ////dans la configuration je vais demandé à spring securité que chaque requete qui arrive vers le serveur tu appel cette filtrecette methode est s'executen pour chaque requete, filtre c'est un middlewaren,chaque methode arrive cette requete s'excuten
        try {
            String jwt = parseJwt(request);
            if (jwt != null && jwtUtils.validateJwtToken(jwt)) { //1: je doit verifier que le token est valide (correcte )
                String userEmail = jwtUtils.getUserNameFromJwtToken(jwt); //2.j'extraire le username à partie le token

                UserDetails userDetails = userDetailsService.loadUserByUsername(userEmail); //3.//je vais chargé l'utlisateur depuis la base de donnes pour voir s'il existe ou nn
                UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken( //4.//c'est un objet de springSecurity:je vais authentifié cet utlisateur
                        userDetails, null, userDetails.getAuthorities());
                authentication.setDetails(new WebAuthenticationDetailsSource().buildDetails(request)); //4.je vais creer un authentification token pour mon utlisateur recuperer ,

                SecurityContextHolder.getContext().setAuthentication(authentication); //l'authentification est fait avec succes
            }
        } catch (Exception e) {
            logger.error("Cannot set user authentication: {}", e);
        }

        filterChain.doFilter(request, response);
    }

    private String parseJwt(HttpServletRequest request) { //chaque requete arrive elle doit representer son visa(Authorization)
        ///1.je vais recuperer le JWT li fl header on utlisant l'objet request
        //2.je vais verifier la signature de JWT
        String headerAuth = request.getHeader("Authorization");// ce jwt je peut envoyer le token au client dans le header qui s'appel Authorization
        //je vais utiliser request pour lire le header autorization(jwt)
        // getHeader p:pour spécifier l'authentifcation
        if (StringUtils.hasText(headerAuth) && headerAuth.startsWith("Bearer ")) //bearer c'est pour dire quil ya un jwt qui contient touts les infromations sur la session(token) ,c'est un presfixe
        {
            return headerAuth.substring(7, headerAuth.length()); //pour enlever le bearer du jwt
        }

        return null;
    }
}

