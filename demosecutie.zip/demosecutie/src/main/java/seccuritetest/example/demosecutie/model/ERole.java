package seccuritetest.example.demosecutie.model;


    public enum  ERole {
        ROLE_CLIENT,
        ROLE_ADMIN,
        ROLE_INTERNAUTE,
    }


