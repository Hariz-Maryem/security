package seccuritetest.example.demosecutie.security;

import seccuritetest.example.demosecutie.security.jwt.AuthEntryPointJwt;
import seccuritetest.example.demosecutie.security.jwt.AuthTokenFilter;
import seccuritetest.example.demosecutie.services.UserDetailsServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;


@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(
		// securedEnabled = true,
		// jsr250Enabled = true,
		prePostEnabled = true)
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {
	@Autowired
	UserDetailsServiceImpl userDetailsService;

	@Autowired
	private AuthEntryPointJwt unauthorizedHandler;

	@Bean
	public AuthTokenFilter authenticationJwtTokenFilter() {

		return new AuthTokenFilter();
	}

	@Override
	public void configure(AuthenticationManagerBuilder authenticationManagerBuilder) throws Exception {
		////spring security il va chercher les utilisateur et les roles,on va spécifié quel sont les utlisateurs qui ont les droits d'acceder, par la suite en fait la comparasion de mot de passe et la suite
		authenticationManagerBuilder.userDetailsService(userDetailsService).passwordEncoder(passwordEncoder()); //on va dit à spring que pour faire l 'authentification voila mon service quiva  permettre à chercher les informations de l'utlisateur à partie de la base de données, tu loid donne le username et tu trécupéri l 'utlisateur avec ses roles,userDetailsService :c'est un service founit par spring
	}

	@Bean
	@Override
	public AuthenticationManager authenticationManagerBean() throws Exception {
		return super.authenticationManagerBean();
	}

	@Bean
	public PasswordEncoder passwordEncoder() { //pour encoder le mot d epasse
		return new BCryptPasswordEncoder();
	}

	@Override
	protected void configure(HttpSecurity http) throws Exception { //on va autorisé l'accées à toute les fonctinaloté (get,post,put,delet)
		http.cors().and().csrf().disable()
			.exceptionHandling().authenticationEntryPoint(unauthorizedHandler).and() //2: executer la cofiguation
			.sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS).and()
			.authorizeRequests().antMatchers("/api/auth/**").permitAll()// //je suis entrain de dire à spring sécurité tout se qui est ("/api/auth/**""...) je lepermet, donc je n'est pas besoin frocement passé par une authentification pour permrttre cette opération là
				 .antMatchers("/api/user/**").permitAll()
			.antMatchers("/api/test/**").permitAll()
			.anyRequest().authenticated();


		http.addFilterBefore(authenticationJwtTokenFilter(), UsernamePasswordAuthenticationFilter.class); //1 executer le filtre : filtrer requet :je vais demandé à spring securité que chaque requete qui arrive vers le serveur tu appel cette filtrecette methode est s'executen pour chaque requete
	}
}
