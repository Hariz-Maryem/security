package seccuritetest.example.demosecutie;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemosecutieApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemosecutieApplication.class, args);
	}

}
