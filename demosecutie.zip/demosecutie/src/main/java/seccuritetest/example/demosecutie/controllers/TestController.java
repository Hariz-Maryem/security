package seccuritetest.example.demosecutie.controllers;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

//Contrôleur pour tester l'autorisation
@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/test")
public class TestController {


  @GetMapping("/user")
  public String userAccess() {
return "public content user ";
  }

  @GetMapping("/visiteur")
  @PreAuthorize("hasRole('CLIENT') or hasRole('INTERNAUTE') or hasRole('ADMIN')")
  public String visiteurAccess() {

    return "Public Content.";
  }

  @GetMapping("/espaceclient")
  @PreAuthorize("hasRole('CLIENT')")
  public String clientAccess() {
    return "CLIENT Board.";
  }

  @GetMapping("/int")
  @PreAuthorize("hasRole('INTERNAUTE')")
  public String moderatorAccess() {
    return "INTERNAUTE Board.";
  }

  @GetMapping("/espaceadmin")
  @PreAuthorize("hasRole('ADMIN')")
  public String adminAccess() {
    return "Admin Board.";
  }
}
